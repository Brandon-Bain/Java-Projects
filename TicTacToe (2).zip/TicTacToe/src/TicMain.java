/*
 * Brandon
 * 11/20/2016
 * Tic Tac Toe
 */
public class TicMain {

    public static void main(String[] args){
        TicOperation start1 = new TicOperation();

        start1.runGame();
    }
}
