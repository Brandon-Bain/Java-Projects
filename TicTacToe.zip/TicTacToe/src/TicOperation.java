import java.util.Scanner;

/*
 * Brandon Bain
 * 11/20/2016
 * Tic Tac Toe
 */

public class TicOperation {

    private int player1 = 1;
    private int player2 = 2;
    private int[] board = new int[9];
    private int currentPlayer = 1;
    private int placement;
    private int winningPlayer;

    public void getUserInput(){
        Scanner scan1 = new Scanner(System.in);

        System.out.println("Player "+currentPlayer+" enter position to play. (0-9)");
        placement = scan1.nextInt();
        checkUserInput();
    }

    public void checkUserInput(){
        if (placement > 8)
            getUserInput();
    }

    public void setPlayer1(){
        currentPlayer = player1;
    }

    public void setPlayer2(){
        currentPlayer = player2;
    }

    public void makeMove(){
        board[placement] = currentPlayer;
    }


    public void winCheck(){
        //Check first line across
        if (board[0] != 0 && board[0] == board[1] && board[0] == board[2])
            winningPlayer = currentPlayer;
        //Check top left to bottom right diagonal
        else if (board[0] != 0 && board[0] == board[4] && board[0] == board[8])
            winningPlayer = currentPlayer;
        //Check second line across
        else if (board[3] != 0 && board[3] == board[4] && board[3] == board[5])
            winningPlayer = currentPlayer;
        //Check third line across
        else if (board[6] != 0 && board[6] == board[7] && board[6] == board[8])
            winningPlayer = currentPlayer;
        //Check first column
        else if (board[0] != 0 && board[0] == board[3] && board[0] == board[6])
            winningPlayer = currentPlayer;
        //Check second column
        else if (board[1] != 0 && board[1] == board[4] && board[1] == board[7])
            winningPlayer = currentPlayer;
        //Check third column
        else if (board[2] != 0 && board[2] == board[5] && board[2] == board[8])
            winningPlayer = currentPlayer;
        //Check top right to bottom left diagonal
        else if (board[2] != 0 && board[2] == board[4] && board[2] == board[6])
            winningPlayer = currentPlayer;
        else if (board[0] != 0 && board[1] != 0 && board[2] != 0 && board[3] != 0 && board[4] != 0 && board[5] != 0 && board[6] != 0 && board[7] != 0 && board[8] != 0)
            winningPlayer = 3;
        else if (currentPlayer == 1)
            setPlayer2();
        else if (currentPlayer == 2)
            setPlayer1();
    }

    public void takeTurn(){
        System.out.println();
        System.out.println();
        System.out.println();
        System.out.println();
        System.out.println();

        System.out.println("Current Board (0 means empty):"+"\t"+"\t"+"\t"+"Position Numbers");
        System.out.println(board[0]+"\t"+board[1]+"\t"+board[2]+"\t"+"\t"+"\t"+"\t"+"\t"+"\t"+"\t"+"\t"+"0\t1\t2");
        System.out.println(board[3]+"\t"+board[4]+"\t"+board[5]+"\t"+"\t"+"\t"+"\t"+"\t"+"\t"+"\t"+"\t"+"3\t4\t5");
        System.out.println(board[6]+"\t"+board[7]+"\t"+board[8]+"\t"+"\t"+"\t"+"\t"+"\t"+"\t"+"\t"+"\t"+"6\t7\t8");
        getUserInput();
        makeMove();
        winCheck();
    }

    public void runGame(){
        while (winningPlayer == 0){
            takeTurn();
        }
        if (winningPlayer != 3)
            System.out.println("Player "+currentPlayer+" has won.");
        else if (winningPlayer == 3)
            System.out.println("Game is a draw.");
    }


}
