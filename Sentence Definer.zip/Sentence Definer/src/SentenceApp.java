/*
 * Brandon Bain
 * 10/23/2016
 * Sentence type evaluation
 */

import javax.swing.JOptionPane;
import java.util.Objects;


public class SentenceApp {

    private String inputSentence;
    private String lastChar;

    public void sentenceLogic() {

        if (Objects.equals(lastChar, "."))
            JOptionPane.showMessageDialog(null, "Sentence is a declarative. ");

        else if (Objects.equals(lastChar, "!"))
            JOptionPane.showMessageDialog(null, "Sentence is an exclamation.");

        else if (Objects.equals(lastChar, "?"))
            JOptionPane.showMessageDialog(null, "Sentence is a question.");

        else
            JOptionPane.showMessageDialog(null, "Sentence is invalid");
    }


    public void SentenceGetter() {

        //Displaying dialog box to grab sentence from user.
        inputSentence = JOptionPane.showInputDialog("Enter Complete Sentence: ");

    }

    public void getLastCharacter() {

        //Get Sentence length and last character for comparison.
        lastChar = inputSentence.substring(inputSentence.length() - 1);

    }
}