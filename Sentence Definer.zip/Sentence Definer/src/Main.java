/*
 * Brandon Bain
 * 10/23/2016
 * Sentence type evaluation.
 */
public class Main {

    public static void main(String[] args){

        SentenceApp sentence1 = new SentenceApp();

        sentence1.SentenceGetter();
        sentence1.getLastCharacter();
        sentence1.sentenceLogic();

    }
}
