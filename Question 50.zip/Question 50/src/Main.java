/**
 * Created by Brandon on 10/18/2016.
 * Question 50
 * Season Calculator
 */

public class Main {

    public static void main(String[] args){

        SeasonConverter arg1 = new SeasonConverter();

        arg1.ScanTemp();
        arg1.SeasonCalc();

    }
}
