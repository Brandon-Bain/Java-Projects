/*
 * Brandon
 * 10/18/2016
 */

import java.util.Scanner;

public class SeasonConverter {

    private int iTempInput;

    public void ScanTemp() {
        Scanner tempscan = new Scanner(System.in);

        System.out.print("What is the temperature: ");
        iTempInput = tempscan.nextInt();
    }

    public void SeasonCalc(){
        if (iTempInput >= 90 && iTempInput < 110)
            System.out.println("It is most likely Summer. ");

        else if (iTempInput >= 70 && iTempInput < 90)
            System.out.println("It is most likely Spring. ");

        else if (iTempInput >= 50 && iTempInput < 70)
            System.out.println("It is most likely Fall. ");

        else if (iTempInput < 50 && iTempInput > -5)
            System.out.println("It is most likely Winter. ");
        else
            System.out.println("Temperature entered is out of range. ");

    }





}
