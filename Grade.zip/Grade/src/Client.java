/*
 * Brandon Bain
 * 11/13/2016
 * Grade Class
 */
public class Client {

    public static void main(String args[]){

    }
}
