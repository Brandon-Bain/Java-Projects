/*
 * Brandon Bain
 * 11/13/2016
 * Grade methods
 */
public class Grade {

    public Grade() {
        sCourseName = "";
        sLetterGrade = "";
    }

    @Override
    public String toString() {
        return "Grade{" +
                "sCourseName='" + sCourseName + '\'' +
                ", sLetterGrade='" + sLetterGrade + '\'' +
                '}';
    }

    String sCourseName, sLetterGrade;

    public String getsCourseName() {
        return sCourseName;
    }

    public void setsCourseName(String sCourseName) {
        this.sCourseName = sCourseName;
    }

    public String getsLetterGrade() {
        return sLetterGrade;
    }

    public void setsLetterGrade(String sLetterGrade) {
        this.sLetterGrade = sLetterGrade;
    }



}
