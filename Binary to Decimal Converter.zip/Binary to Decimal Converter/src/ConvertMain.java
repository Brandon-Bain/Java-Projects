/*
 * Brandon Bain
 * 10/31/2016
 * Convert Binary user inputs into Decimal.
 */
public class ConvertMain {

    public static void main(String[] args){
        //firstConvert used for testing long conversion of Binary to Decimal

        //BinaryToIntConverter firstConvert = new BinaryToIntConverter();
        BinaryToIntConverter secondConvert = new BinaryToIntConverter();
        IntToBinaryConverter thirdConvert = new IntToBinaryConverter();

        //firstConvert.GetBinary();
        //firstConvert.Cheat();
        //firstConvert.Printer();

        secondConvert.GetBinary();
        secondConvert.NumWork();
        secondConvert.Printer();

        thirdConvert.getInput();
        thirdConvert.IntWork();
        thirdConvert.Print();

    }
}
