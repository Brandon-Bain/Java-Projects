/*
 * Brandon Bain
 * 10/31/2016
 * Binary to Decimal Conversion methods
 */

import java.util.Scanner;

public class BinaryToIntConverter {

    String sBinaryInput;    //Stores users binary input
    Integer iBinLength;     //Stores length of user's binary input
    double output;          //Stores output to be printed


    public void GetBinary(){
        //Create Scanner and assign to sBinaryInput

        Scanner newScan = new Scanner(System.in);

        System.out.println("Enter a binary Number: ");
        sBinaryInput = newScan.next();

    }

    public void NumWork(){
        //Math work to calculate decimal number to Binary
        iBinLength = sBinaryInput.length();

        for(int i = 0; i < iBinLength; i++){
            if (sBinaryInput.charAt(i) == '1'){
                output = output+ Math.pow(2,iBinLength-1-i);
            }
        }
    }

    public void Cheat(){
        //Only used to make sure NumWork is working correctly. Used in firstConvert in Main Class
        output = Integer.parseInt(sBinaryInput, 2);
    }

    public void Printer(){
        //Printer method to print the "output" variable
        System.out.println(sBinaryInput + " in decimal form is: "+output);
    }
}
