import java.util.Scanner;

/*
 * Brandon Bain
 * 11/3/2016
 * Integer to Binary Converter
 */
public class IntToBinaryConverter {

    int iIntegerInput, iOriginalInput;
    String sOutputInt = "";



    public void getInput(){
        Scanner scan2 = new Scanner(System.in);

        System.out.println("Enter any Integer Number: ");

        iIntegerInput = scan2.nextInt();
        iOriginalInput = iIntegerInput;


    }

    public void IntWork(){
        //Class for

        for (int i = 0; i < 8; i++){
            if (iIntegerInput % 2 == 1){
                sOutputInt = '1' + sOutputInt;
            }
            if (iIntegerInput % 2 == 0){
                sOutputInt = '0' + sOutputInt;
            }
            iIntegerInput = iIntegerInput / 2;
        }
    }

    public void Print(){
        //Class Used to print the output
        System.out.println(iOriginalInput+" In decimal form is: "+sOutputInt);
    }
}
